package DAOs;
import Entidades.Poltrona;
import java.util.ArrayList;
import java.util.List;

public class DAOPoltrona extends DAOGenerico<Poltrona> {

    public DAOPoltrona() {
        super(Poltrona.class);
    }

    public int autoIdPoltrona() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.idPoltrona) FROM Poltrona e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Poltrona> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Poltrona e WHERE e.nome LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Poltrona> listById(int id) {
        return em.createQuery("SELECT e FROM Poltrona e WHERE e.idPoltrona = :id").setParameter("id", id).getResultList();
    }

    public List<Poltrona> listInOrderNome() {
        return em.createQuery("SELECT e FROM Poltrona e ORDER BY e.nome").getResultList();
    }

    public List<Poltrona> listInOrderId() {
        return em.createQuery("SELECT e FROM Poltrona e ORDER BY e.idPoltrona").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Poltrona> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getNPoltrona()
 + "-" + lf.get(i).getNome()
 + "-" + lf.get(i).getDocumento()
);
        }
        return ls;
    }
}
